<center><h1>Tablette V1</h1></center><br>
Afin de configurer la touche d'ouverture de la tablette rendez-vous dans:<br>
- tablette/client.lua et modifier la <b>ligne 29</b> ( if IsControlJustReleased(0, 23) and IsInputDisabled(0) then )<br>
- remplacer par if IsControlJustReleased(0, <b>LATOUCHEQUEVOUSSOUHAITEZ</b>) and IsInputDisabled(0) then<br>
- ensure tablette (<b>NE MODIFIER PAS LE NOM DE LA RESSOURCE</b>)<br>
- La tablette est crypté dans le côté html et JavaScript.
<hr>
Vidéo: https://www.youtube.com/watch?v=SSNkXjE51_0 <br>
Lien pour les touches: https://docs.fivem.net/docs/game-references/controls/
<hr>
Hébergeur FiveM Vraiment pas chers c'est ici -> http://fiveheberg.fr/ <br>
Discord de FiveHeberg.fr -> https://discord.gg/ehcYrtYkYD
<hr><br>
<img src="https://i.goopics.net/5vi4wn.png">
